#ifndef LTP_H
#define LTP_H

#include <stdint.h>
#include <stdbool.h>

#define LTP_FEND              0x7E
#define LTP_ESC               0x7D
#define LTP_PROTOCOL_VERSION  0x01
#define LTP_MAX_PAYLOAD       512

typedef struct
{
    uint8_t  version;
    uint8_t  address;
    uint8_t  command;
    uint8_t  flags;

    uint16_t sequence;
    uint16_t length;

    uint8_t* payload;

    uint16_t crc;

} ltp_packet_t;

typedef struct
{
    uint8_t  state;
    uint8_t  header[8];
    uint8_t  payload[LTP_MAX_PAYLOAD];

    uint16_t header_index;
    uint16_t payload_index;
    uint16_t expected_length;

    bool escaped;

} ltp_parser_t;

void ltp_parser_init(ltp_parser_t* parser);

bool ltp_parse_byte(
    ltp_parser_t* parser,
    uint8_t byte,
    ltp_packet_t* packet);

uint16_t ltp_crc16(
    const uint8_t* data,
    uint16_t length);

#endif
